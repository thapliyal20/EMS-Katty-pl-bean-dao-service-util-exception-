package com.emp.service;

import com.emp.exception.EmployeeException;
import comp.emp.bean.EmployeeBean;

public interface EmployeeService {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
}
