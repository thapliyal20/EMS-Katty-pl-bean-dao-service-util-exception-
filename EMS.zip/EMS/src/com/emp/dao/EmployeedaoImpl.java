package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;




import comp.emp.bean.EmployeeBean;

public class EmployeedaoImpl implements EmployeeDao{

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		try {
			Connection con=null;
			int id=generateEmployeeId();
			String cmd="insert into emp_table(empid,empname,empSal) values(?,?,?)";
			con=DBConnection.getConnection();
			PreparedStatement pstmt= con.prepareStatement(cmd);
			pstmt.setInt(1,id);
			pstmt.setString(2,bean.getEmployeeName());
			pstmt.setInt(3,bean.getEmployeeSalary());
			pstmt.executeUpdate();
			System.out.println("Employee added: "+id);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int generateEmployeeId() 
	{
		int id=0;
		try {
		
			Connection con=null;
			String cmd="select empid_sequence.nextval from dual";
			try {
				con=DBConnection.getConnection();
			} catch (Exception e) {
				e.printStackTrace();
			}
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(cmd);
			rst.next();
			id=rst.getInt(1);
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
}
