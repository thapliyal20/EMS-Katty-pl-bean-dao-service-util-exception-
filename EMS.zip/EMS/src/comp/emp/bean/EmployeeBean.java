package comp.emp.bean;

public class EmployeeBean {

		private int employeeId;
		private String employeeName;
		private int employeeSalary;
		
		public EmployeeBean() {
			
		}
		
		public EmployeeBean(int employeeId, String employeeName,
				int employeeSalary) {
		
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeSalary = employeeSalary;
		}

		public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public int getEmployeeSalary() {
			return employeeSalary;
		}
		public void setEmployeeSalary(int employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
		
		
}
