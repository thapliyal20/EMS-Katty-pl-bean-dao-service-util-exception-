package com.emp.pl;

import java.util.Scanner;

import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;

import comp.emp.bean.EmployeeBean;

public class EMSApp {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner (System.in);
		int id=0;
		System.out.println(" Enter Empoloyee Name");
		String name=sc.next();
		System.out.println("Enter Salary");
		int salary = sc.nextInt();
		EmployeeBean bean= new EmployeeBean();
		bean.setEmployeeName(name);
		bean.setEmployeeSalary(salary);
		EmployeeServiceImpl service = new EmployeeServiceImpl();
		
		try {
			service.addEmployee(bean);
		} catch (EmployeeException e) {
		System.out.println("Unable to insert");
		}
		
		
		
		
	}

}
