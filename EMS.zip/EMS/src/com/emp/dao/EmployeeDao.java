package com.emp.dao;

import com.emp.exception.EmployeeException;
import comp.emp.bean.EmployeeBean;

public interface EmployeeDao {

		public int addEmployee(EmployeeBean bean) throws EmployeeException;
}
