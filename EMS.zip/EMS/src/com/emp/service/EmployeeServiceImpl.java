package com.emp.service;

import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeedaoImpl;
import com.emp.exception.EmployeeException;

import comp.emp.bean.EmployeeBean;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		EmployeeDao dao=new EmployeedaoImpl();
		int id=dao.addEmployee(bean);
		return id;
	}
	

}
